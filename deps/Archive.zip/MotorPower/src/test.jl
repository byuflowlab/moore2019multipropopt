using PyPlot


rc("figure", figsize=(6.5, 5.2))
rc("font", size=10.0)
rc("lines", linewidth=1.5)
rc("lines", markersize=3.0)
rc("legend", frameon=false)
rc("axes.spines", right=false, top=false)
# rc("figure.subplot", left=0.17, bottom=0.21, top=0.97, right=.65)
rc("figure.subplot", left=0.12, bottom=0.12, top=0.99, right=.95)
rc("axes", color_cycle=["348ABD", "A60628", "009E73", "7A68A6", "D55E00", "CC79A7"])
plot_cycle=["#348ABD", "#A60628", "#009E73", "#7A68A6", "#D55E00", "#CC79A7"]
close("all")

figname = "Propulsion_ETA_Cruise_db"
figure(figname)
plot(linspace(0,1000,2),linspace(0,700,2),"w")
xlabel("Energy Density (Wh/L)")
ylabel("Specific Energy (Wh/kg)")
savefig("/Users/kmoore/Desktop/$figname.pdf",transparent = true)
