# This is an auto-generated file; do not edit

# Pre-hooks

if VERSION >= v"0.7.0-DEV.3382"
    using Libdl
end
# Macro to load a library
macro checked_lib(libname, path)
    if Libdl.dlopen_e(path) == C_NULL
        error("Unable to load \n\n$libname ($path)\n\nPlease ",
              "re-run Pkg.build(package), and restart Julia.")
    end
    quote
        const $(esc(libname)) = $path
    end
end

# Load dependencies
@checked_lib libxfoil "/Users/kmoore/.julia/v0.6/Xfoil/deps/usr/lib/libxfoil.dylib"
@checked_lib libxfoil_cs "/Users/kmoore/.julia/v0.6/Xfoil/deps/usr/lib/libxfoil_cs.dylib"

# Load-hooks

