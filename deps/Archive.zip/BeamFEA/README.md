# BeamFEA

[![Build Status](https://travis-ci.org/andrewning/BeamFEA.jl.svg?branch=master)](https://travis-ci.org/andrewning/BeamFEA.jl)

[![Coverage Status](https://coveralls.io/repos/andrewning/BeamFEA.jl/badge.svg?branch=master&service=github)](https://coveralls.io/github/andrewning/BeamFEA.jl?branch=master)

[![codecov.io](http://codecov.io/github/andrewning/BeamFEA.jl/coverage.svg?branch=master)](http://codecov.io/github/andrewning/BeamFEA.jl?branch=master)
