module BrentMin
export brent_min

"""
Translated and simplified by KRM, the original was non-intuitive and not in stand alone fashion as it is now.

# Inputs
- a, b : brackets
- fun : pointer to function (just pass in the function for julia)
- tol : convergence tolerance
- iters : number of iterations allowed
- messages: boolean, track what brent method is doing or not
- singleoutput : boolean, return tested points on function, or just the minimum

# Outputs:
- funxsave,funfxsave : x and y points along the line tested (unless singleoutput = true, then last point tested (min))
"""
function brent_min(a, b, fun; tol=1e-6, iters=20, messages=false, singleoutput=false)


    # Original comments from the matlab version
    #*****************************************************************************80
    #
    ## LOCAL_MIN_RC seeks a minimizer of a scalar function of a scalar variable.
    #
    #  Discussion:
    #
    #    This routine seeks an approximation to the point where a function
    #    F attains a minimum on the interval (A,B).
    #
    #    The method used is a combination of golden section search and
    #    successive parabolic interpolation.  Convergence is never much
    #    slower than that for a Fibonacci search.  If F has a continuous
    #    second derivative which is positive at the minimum (which is not
    #    at A or B), then convergence is superlinear, and usually of the
    #    order of about 1.324...
    #
    #    The routine is a revised version of the Brent local minimization
    #    algorithm, using reverse communication.
    #
    #    It is worth stating explicitly that this routine will NOT be
    #    able to detect a minimizer that occurs at either initial endpoint
    #    A or B.  If this is a concern to the user, then the user must
    #    either ensure that the initial interval is larger, or to check
    #    the function value at the returned minimizer against the values
    #    at either endpoint.
    #
    #  Licensing:
    #
    #    This code is distributed under the GNU LGPL license.
    #
    #  Modified:
    #
    #    22 October 2004
    #
    #  Author:
    #
    #    John Burkardt
    #
    #  Reference:
    #
    #    Richard Brent,
    #    Algorithms for Minimization Without Derivatives,
    #    Dover, 2002,
    #    ISBN: 0-486-41998-3,
    #    LC: QA402.5.B74.
    #
    #    David Kahaner, Cleve Moler, Steven Nash,
    #    Numerical Methods and Software,
    #    Prentice Hall, 1989,
    #    ISBN: 0-13-627258-4,
    #    LC: TA345.K34.
    #
    #  Parameters
    #
    #    Input, real A, B, the lower and upper bounds for an interval containing
    #    the minimizer.  It is required that A < B.
    #
    #    Input, integer STATUS, used to communicate between the user and the routine.
    #    The user only sets STATUS to zero on the first  call, to indicate that this
    #    is a startup call.  On each subsequent call, the input value of STATUS
    #    should be its output value from the previous call.
    #
    #    Input, real VALUE, the function value at ARG, as requested
    #    by the routine on the previous call.
    #
    #    Output, real ARG, the currently estimate for the minimizer.  On return
    #    with STATUS positive, the user is requested to evaluate the function at ARG,
    #    and return the value in VALUE.  On return with STATUS zero, ARG is the routine's
    #    estimate for the function minimizer.
    #
    #    Output, integer STATUS.  The routine returns STATUS positive to request
    #    that the function be evaluated at ARG, or returns STATUS as 0, to indicate
    #    that the iteration is complete and that ARG is the estimated minimizer.
    #
    #    Output, real A, B, the lower and upper bounds for an interval containing
    #    the minimizer.
    #
    #
    #  Local parameters:
    #
    #    C is the squared inverse of the golden ratio.
    #
    #    EPS_SQRT is the square root of the relative machine precision.
    #


    status = 0
    x = 0
    u=0
    d=0
    c=0
    v=0
    w=0
    fx=0
    fw=0
    fv=0
    fxold = 100
    eps = sqrt.(1e-24)
    e=0.0
    funx=0

    funxsave = zeros(iters)
    funfxsave = zeros(iters)

    for i = 1:iters

        if ( status == 0 )

            if ( b <= a )
                if messages == true
                    println("Brackets inverted, swapping a and b")
                end
                temp = b
                b = a
                a=temp
            end
            c = 0.5 * ( 3.0 - sqrt.( 5.0 ) )
            v = a + c * ( b - a )
            w = v
            x = v
            e = 0.0

            status = 1
            funx = x
        end
        #
        #  STATUS (INPUT) = 1, break with initial function fun of FX.
        #
        if ( status == 1 )

            fx = fun(funx)
            funxsave[i] = funx
            funfxsave[i] = fx
            fv = fx
            fw = fx
            #
            #  STATUS (INPUT) = 2 or more, update the data.
            #
        elseif ( status>1 )

            fu = fun(funx)
            funxsave[i] = funx
            funfxsave[i] = fu

            if ( fu <= fx )

                if ( x <= u )
                    a = x
                else
                    b = x
                end

                v = w
                fv = fw
                w = x
                fw = fx
                x = u
                fx = fu

            else

                if ( u < x )
                    a = u
                else
                    b = u
                end

                if ( fu <= fw || w == x )
                    v = w
                    fv = fw
                    w = u
                    fw = fu
                elseif ( fu <= fv || v == x || v == w )
                    v = u
                    fv = fu
                end

            end

        end
        #
        #  Take the next step.
        #
        midpoint = 0.5 * ( a + b )
        tol1 = eps * abs( x ) + tol / 3.0
        tol2 = 2.0 * tol1
        #
        #  If the stopping criterion is satisfied, we can exit.
        #
        if ( abs( x - midpoint ) <= ( tol2 - 0.5 * ( b - a ) ) ) #|| (abs(fx-fxold)<tol)
            for j = i:iters
                funxsave[j] = funxsave[i]
                funfxsave[j] = funfxsave[i]
            end
            if messages == true
                println("BrentMin: Stopping Criteria Reached")
            end
            if singleoutput == true
                return funxsave[end],funfxsave[end]
            else
                return funxsave,funfxsave
            end
        end
        #
        #  Is golden-section necessary?
        #
        if ( abs( e ) <= tol1 )

            if ( midpoint <= x )
                e = a - x
            else
                e = b - x
            end

            d = c * e
            #
            #  Consider fitting a parabola.
            #
        else

            r = ( x - w ) * ( fx - fv )
            q = ( x - v ) * ( fx - fw )
            p = ( x - v ) * q - ( x - w ) * r
            q = 2.0 * ( q - r )
            if ( 0.0 < q )
                p = - p
            end
            q = abs( q )
            r = e
            e = d
            #
            #  Choose a golden-section step if the parabola is not advised.
            #
            if ( ( abs( 0.5 * q * r ) <= abs( p ) ) || ( p <= q * ( a - x ) ) || ( q * ( b - x ) <= p ) )

                if ( midpoint <= x )
                    e = a - x
                else
                    e = b - x
                end

                d = c * e
                #
                #  Choose a parabolic interpolation step.
                #
            else

                d = p / q
                u = x + d

                if ( ( u - a ) < tol2 )
                    d = tol1*sign( midpoint - x )
                end

                if ( ( b - u ) < tol2 )
                    d = tol1*sign( midpoint - x )
                end

            end

        end
        #
        #  F must not be evaluated too close to X.
        #
        if ( tol1 <= abs( d ) )
            u = x + d
        end

        if ( abs( d ) < tol1 )
            u = x + tol1*sign(d)
        end
        #
        #  Request fun of F(U).
        #
        funx = u
        # println(status)
        status = status + 1
    end
    warn("BrentMin: Max Iters Reached")
    return funxsave,funfxsave
end
end #module
