# BrentMin

[![Build Status](https://travis-ci.org/moore54/BrentMin.jl.svg?branch=master)](https://travis-ci.org/moore54/BrentMin.jl)

[![Coverage Status](https://coveralls.io/repos/moore54/BrentMin.jl/badge.svg?branch=master&service=github)](https://coveralls.io/github/moore54/BrentMin.jl?branch=master)

[![codecov.io](http://codecov.io/github/moore54/BrentMin.jl/coverage.svg?branch=master)](http://codecov.io/github/moore54/BrentMin.jl?branch=master)


# Installation

```julia

Pkg.clone("the_git_url")

```

# Testing

```julia

Pkg.test("BrentMin")

```

# Using the package

```julia
import BrentMin

minx, miny = brent_min(-10,10,myfun; iters=200, tol=1e-8, singleoutput = true)
```

# I/O
```julia

"""
Translated and simplified by KRM, the original was non-intuitive and not in stand alone fashion as it is now.

# Inputs
- a, b : brackets
- fun : pointer to function (just pass in the function for julia)
- tol : convergence tolerance
- iters : number of iterations allowed
- messages: boolean, track what brent method is doing or not
- singleoutput : boolean, return tested points on function, or just the minimum

# Outputs:
- funxsave,funfxsave : x and y points along the line tested (unless singleoutput = true, then last point tested (min))
"""

```
