using BrentMin
using PyPlot
using Base.Test

# Test code
function myfun(x)
  f = (x-8).^2+10+x.*sin.((x/2).^2)
  return f
end

@testset "Simple Minimization" begin

    #Plot the function
    xplot = linspace(10,-10,1000)
    fplot = myfun(xplot)
    PyPlot.figure()
    PyPlot.plot(xplot,fplot)

    # Plot brent's method evaluation points
    x,y = brent_min(-10,10,myfun)
    PyPlot.plot(x,y,"x")

    minx,miny = brent_min(-10,10,myfun;iters = 200,tol = 1e-8,singleoutput = true)
    PyPlot.plot(minx,miny,"r.")

    @test minx ≈ 8.31610353721409  atol=1e-6
    @test miny ≈ 1.7842881861994115  atol=1e-6

end  # end unit test
