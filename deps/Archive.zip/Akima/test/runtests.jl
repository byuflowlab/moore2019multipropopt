using Akima
using PyPlot

rc("figure", figsize=(4.8, 2.6))
rc("font", size=10.0)
rc("lines", linewidth=1.5)
rc("lines", markersize=3.0)
rc("legend", frameon=false)
rc("axes.spines", right=false, top=false)
rc("figure.subplot", left=0.17, bottom=0.18, top=0.97, right=.89)
rc("axes", color_cycle=["348ABD", "A60628", "009E73", "7A68A6", "D55E00", "CC79A7"])
plot_cycle=["#348ABD", "#A60628", "#009E73", "#7A68A6", "#D55E00", "#CC79A7"]
close("all")


@static if VERSION < v"0.7.0-DEV.2005"
    using Base.Test
else
    using Test
end

@testset "Akima Example" begin

"""
example.py
Created by Andrew Ning on 2013-12-17.
Modified for julia by Kevin Moore on 2018-5-21.
"""

# setup spline based on fixed points
xpt = ([1.0, 2.0, 4.0, 6.0, 10.0, 12.0])
ypt = ([5.0, 12.0, 14.0, 16.0, 21.0, 29.0])
spline = Akima.akima(xpt, ypt)

# interpolate  (extrapolation will work, but beware the results may be silly)
n = 50
x = linspace(0.0, 13.0, n)
y, dydx, dydxpt, dydypt = Akima.interp(spline,x)

# an alternative way to call akima if you don't care about derivatives
# (and also don't care about evaluating the spline multiple times)
# a slight amount of smoothing is used for the one with derivatives so
# y will not exactly match y2 unless you set delta_x=0.0 in the Akima constructor
y2 = Akima.interp_noderiv(xpt, ypt, x)



# compare derivatives w.r.t. x to finite differencing
h = 1e-6
xstep = x + h  # can do all steps at same time b.c. they are independent
ystep, _, _, _ = Akima.interp(spline,xstep)
fd = (ystep - y)/h

# compare derivatives of xpt and ypt for one point
idx = 3
xptstep = copy(xpt)
xptstep[idx] += h
spline = Akima.akima(xptstep, ypt)
ystep, _, _, _ = Akima.interp(spline,x)
fd2 = (ystep - y)/h

yptstep = copy(ypt)
yptstep[idx] += h
spline = Akima.akima(xpt, yptstep)
ystep, _, _, _ = Akima.interp(spline,x)
fd3 = (ystep - y)/h

figure()
plot(xpt, ypt, "o",label = "original")
plot(x, y, "-", label = "Akima spline")
xlabel("x")
ylabel("y")
legend(loc = "best")

figure()
plot(x, dydx, label = "Akima dydx")
plot(x, fd, "--", label = "Finite difference dydx")
xlabel("x")
ylabel("dydx")
legend(loc = "best")

figure()
plot(x, dydxpt[:, idx],label = "Akima dydxpt")
plot(x, fd2, "--",label = "Finite difference dydxpt")
xlabel("x")
ylabel("dydxpt")
legend(loc = "best")

figure()
plot(x, dydypt[:, idx],label = "Akima dydypt")
plot(x, fd3, "--",label = "Finite difference dydypt")
xlabel("x")
ylabel("dydypt")
legend(loc = "best")

@test y ≈ y2  atol=5e-1
@test dydx ≈ fd  atol=5e-5
@test dydxpt[:, idx] ≈ fd2  atol=5e-5
@test dydypt[:, idx] ≈ fd3  atol=5e-5

end
