module Akima
# export

"""
akima
Created by Andrew Ning on 2013-12-17.
Modified for julia by Kevin Moore on 2018-5-21.
"""


function interp_noderiv(xpt, ypt, x):
    """convenience method for those who don't want derivatives
    and don't want to evaluate the same spline multiple times"""

    p0, p1, p2, p3 = setup(xpt, ypt; delta_x=0.0)

    npt = length(xpt)
    zerosin = zeros((npt-1, npt))

    y, dydx, dydxpt, dydypt = interp_internal(x, xpt, p0, p1, p2, p3,
        zerosin, zerosin, zerosin, zerosin, zerosin, zerosin, zerosin, zerosin)

    return y
end

struct akima
    xpt::Array{Float64,1}
    delta_x::Float64
    p0::Array{Float64,1}
    p1::Array{Float64,1}
    p2::Array{Float64,1}
    p3::Array{Float64,1}
    dp0_dxpt::Array{Float64,2}
    dp0_dypt::Array{Float64,2}
    dp1_dxpt::Array{Float64,2}
    dp1_dypt::Array{Float64,2}
    dp2_dxpt::Array{Float64,2}
    dp2_dypt::Array{Float64,2}
    dp3_dxpt::Array{Float64,2}
    dp3_dypt::Array{Float64,2}
end


function akima(xpt, ypt; delta_x=0.1):


        """setup akima spline
        Parameters
        ----------
        xpt : array_like
            x discrete data points
        ypt : array_like
            x discrete data points
        delta_x : float, optional
            half-width of the smoothing interval added in the valley of absolute-value function
            this allows the derivatives with respect to the data points (dydxpt, dydypt)
            to also be C1 continuous.
            set to parameter to 0 to get the original Akima function (but only if
            you don't need dydxpt, dydypt)
        """

        npt = length(xpt)
        xptd = ([eye(npt); zeros((npt, npt))])
        yptd = ([zeros((npt, npt)); eye(npt)])

        p0, p0d, p1, p1d, p2, p2d, p3, p3d =setup_dv(xpt, xptd, ypt, yptd; delta_x=delta_x)
        dp0_dxpt = p0d[1:npt, :]'
        dp0_dypt = p0d[npt+1:end, :]'
        dp1_dxpt = p1d[1:npt, :]'
        dp1_dypt = p1d[npt+1:end, :]'
        dp2_dxpt = p2d[1:npt, :]'
        dp2_dypt = p2d[npt+1:end, :]'
        dp3_dxpt = p3d[1:npt, :]'
        dp3_dypt = p3d[npt+1:end, :]'

        # println("$(size(xpt)) \n $(size(delta_x)) \n $(size(p0)) \n $(size(p1)) \n $(size(p2)) \n $(size(p3)) \n $(size(dp0_dxpt)) \n $(size(dp0_dypt)) \n $(size(dp1_dxpt)) \n $(size(dp1_dypt)) \n $(size(dp2_dxpt)) \n $(size(dp2_dypt)) \n $(size(dp3_dxpt)) \n $(size(dp3_dypt)) \n ")
        return akima(xpt,delta_x,p0,p1,p2,p3,dp0_dxpt,dp0_dypt,dp1_dxpt,dp1_dypt,dp2_dxpt,dp2_dypt,dp3_dxpt,dp3_dypt)

    end


    function interp(akima, x):
        """interpolate at new values
        Parameters
        ----------
        x : array_like
            x values to sample spline at
        Returns
        -------
        y : nd_array
            interpolated values y = fspline(x)
        dydx : nd_array
            the derivative of y w.r.t. x at each point
        dydxpt : 2D nd_array (only returned if delta_x != 0.0)
            dydxpt[i, j] the derivative of y[i] w.r.t. xpt[j]
        dydypt : 2D nd_array (only returned if delta_x != 0.0)
            dydypt[i, j] the derivative of y[i] w.r.t. ypt[j]
        """


        # try:
        # #     length(x)
        # #     isFloat = False
        # # except TypeError:  # if x is just a float
        # #     x = ([x])
        # #     isFloat = True

        if size(x) == 0  # error check for empty array
            y = array([])
            dydx = array([])
            dydxpt = array([])
            dydypt = array([])
        else
            y, dydx, dydxpt, dydypt = interp_internal(x,
                akima.xpt, akima.p0, akima.p1, akima.p2, akima.p3,
                akima.dp0_dxpt, akima.dp1_dxpt, akima.dp2_dxpt, akima.dp3_dxpt,
                akima.dp0_dypt, akima.dp1_dypt, akima.dp2_dypt, akima.dp3_dypt)
        end

        # if isFloat:
        #     y = y[0]
        #     dydx = dydx[0]
        #     dydxpt = dydxpt[0, :]
        #     dydypt = dydypt[0, :]
        # end

        if akima.delta_x == 0.0
            return y, dydx
        else
            return y, dydx, dydxpt, dydypt
        end
    end

function abs_smooth(x, delta_x)
    # absolute value function with small quadratic in the valley
    # so that it is C1 continuous

    if (x >= delta_x)
        y = x
    elseif (x <= -delta_x)
        y = -x
    else
        y = x^2/(2.0*delta_x) + delta_x/2.0
    end

    return y

end # abs_smooth


# setup the Akima spline function
function setup(xpt, ypt; delta_x = 1.0)

    n = length(xpt)
    p0 = zeros(n-1)
    p1 = zeros(n-1)
    p2 = zeros(n-1)
    p3 = zeros(n-1)

    # spline coefficients

    m = zeros(2+n+1)

    t = zeros(n)

    # compute segment slopes
    for i = 1:n-1
        m[2+i] = (ypt[i+1] - ypt[i]) / (xpt[i+1] - xpt[i])
    end

    # estimation for end points
    m[2+0] = 2.0*m[2+1] - m[2+2]
    m[2+-1] = 2.0*m[2+0] - m[2+1]
    m[2+n] = 2.0*m[2+n-1] - m[2+n-2]
    m[2+n+1] = 2.0*m[2+n] - m[2+n-1]

    # slope at points
    for i = 1:n
        m1 = m[2+i-2]
        m2 = m[2+i-1]
        m3 = m[2+i]
        m4 = m[2+i+1]
        #         w1 = abs(m4 - m3)
        #         w2 = abs(m2 - m1)
        w1 = abs_smooth(m4 - m3, delta_x)
        w2 = abs_smooth(m2 - m1, delta_x)
        if ( w1 < eps(Float64) && w2 < eps(Float64) )
            t[i] = 0.5*(m2 + m3)  # special case to avoid divide by zero
        else
            t[i] = (w1*m2 + w2*m3) / (w1 + w2)
        end
    end

    # polynomial cofficients
    for i = 1:n-1
        dx = xpt[i+1] - xpt[i]
        t1 = t[i]
        t2 = t[i+1]
        p0[i] = ypt[i]
        p1[i] = t1
        p2[i] = (3.0*m[2+i] - 2.0*t1 - t2)/dx
        p3[i] = (t1 + t2 - 2.0*m[2+i])/dx^2
    end

    return p0, p1, p2, p3

end # setup

# evaluate the Akima spline and its derivatives
function interp_internal(x, xpt, p0, p1, p2, p3,
    dp0dxpt, dp1dxpt, dp2dxpt, dp3dxpt,
    dp0dypt, dp1dypt, dp2dypt, dp3dypt)

    npt = length(xpt)
    n = length(x)

    # out
    y = zeros(n)  # interpolate y values
    dydx = zeros(n)  # derivative of y w.r.t. x
    dydxpt = zeros(n,npt)
    dydypt = zeros(n,npt)  # derivative of y w.r.t. xpt and ypt

    # interpolate at each point
    for i = 1:n

        # find location in array (use end segments if out of bounds)
        if (x[i] < xpt[1])
            j = 1

        else
            # linear search for now
            for j = npt-1:-1:1
                if (x[i] >= xpt[j])
                    break
                end
            end
        end

        # evaluate polynomial (and derivative)
        dx = (x[i] - xpt[j])
        y[i] = p0[j] + p1[j]*dx + p2[j]*dx^2 + p3[j]*dx^3
        dydx[i] = p1[j] + 2.0*p2[j]*dx + 3.0*p3[j]*dx^2

        for k = 1:npt
            dydxpt[i,k] = dp0dxpt[j,k] + dp1dxpt[j,k]*dx + dp2dxpt[j,k]*dx^2 + dp3dxpt[j,k]*dx^3
            if (k == j)
                dydxpt[i,k] = dydxpt[i,k] - dydx[i]
            end
            dydypt[i,k] = dp0dypt[j,k] + dp1dypt[j,k]*dx + dp2dypt[j,k]*dx^2 + dp3dypt[j,k]*dx^3
        end

    end

    return y, dydx, dydxpt, dydypt

end # interp




#        Generated by TAPENADE     (INRIA, Tropics team)
#  Tapenade 3.9 (r5096) - 24 Feb 2014 16:54
#
#  Differentiation of setup in forward (tangent) mode:
#   variations   of useful results: p0 p1 p2 p3
#   with respect to varying inputs: xpt ypt
#   RW status of diff variables: xpt:in p0:out p1:out p2:out p3:out
#                ypt:in

function setup_dv(xpt, xptd, ypt, yptd; delta_x = 0.1)
    #   USE DIFFSIZES
    #  Hint: nbdirsmax should be the maximum number of differentiation directions

    n = length(xpt)
    nbdirs = length(xptd[:,1])

    # out
    # spline coefficients
    p0 = zeros(n-1)
    p1 = zeros(n-1)
    p2 = zeros(n-1)
    p3 = zeros(n-1)

    p0d = zeros(nbdirs, n-1)
    p1d = zeros(nbdirs, n-1)
    p2d = zeros(nbdirs, n-1)
    p3d = zeros(nbdirs, n-1)

    # local

    m = zeros(2+n+1)
    md = zeros(nbdirs,2+n+1)

    t = zeros(n)

    td = zeros(nbdirs, n)

    m1d = zeros(nbdirs)
    m2d = zeros(nbdirs)
    m3d = zeros(nbdirs)
    m4d = zeros(nbdirs)
    w1d = zeros(nbdirs)
    w2d = zeros(nbdirs)

    t1d = zeros(nbdirs)
    t2d = zeros(nbdirs)
    dxd = zeros(nbdirs)
    arg1d = zeros(nbdirs)

    for nd=1:nbdirs
        md[nd,:] = 0.0
    end
    # compute segment slopes
    for i=1:n-1
        for nd=1:nbdirs
            md[nd,2+i] = ((yptd[nd, i+1]-yptd[nd,i])*(xpt[i+1]-xpt[i])-(ypt[i+1]-
            ypt[i])*(xptd[nd, i+1]-xptd[nd,i]))/(xpt[i+1]-xpt[i])^2
        end
        m[2+i] = (ypt[i+1]-ypt[i])/(xpt[i+1]-xpt[i])
    end
    for nd=1:nbdirs
        # estimation for end points
        md[nd,2+0] = 2.0*md[nd,2+1] - md[nd,2+2]
        md[nd,2+-1] = 2.0*md[nd,2+0] - md[nd,2+1]
        md[nd,2+n] = 2.0*md[nd,2+n-1] - md[nd,2+n-2]
        md[nd,2+n+1] = 2.0*md[nd,2+n] - md[nd,2+n-1]
    end
    m[2+0] = 2.0*m[2+1] - m[2+2]
    m[2+-1] = 2.0*m[2+0] - m[2+1]
    m[2+n] = 2.0*m[2+n-1] - m[2+n-2]
    m[2+n+1] = 2.0*m[2+n] - m[2+n-1]
    for nd=1:nbdirs
        td[nd,:] = 0.0
    end
    # slope at points
    for i=1:n
        for nd=1:nbdirs
            m1d[nd] = md[nd,2+i-2]
            m2d[nd] = md[nd,2+i-1]
            m3d[nd] = md[nd,2+i]
            m4d[nd] = md[nd,2+i+1]
            #         w1 = abs(m4 - m3)
            #         w2 = abs(m2 - m1)
            arg1d[nd] = m4d[nd] - m3d[nd]
        end
        m1 = m[2+i-2]
        m2 = m[2+i-1]
        m3 = m[2+i]
        m4 = m[2+i+1]
        arg1 = m4 - m3
        w1, w1d = abs_smooth_dv(arg1, arg1d, delta_x)
        for nd=1:nbdirs
            arg1d[nd] = m2d[nd] - m1d[nd]
        end
        arg1 = m2 - m1
        w2, w2d = abs_smooth_dv(arg1, arg1d, delta_x)
        if (w1 < eps(Float64) && w2 < eps(Float64))
            for nd=1:nbdirs
                # special case to avoid divide by zero
                td[nd,i] = 0.5*(m2d[nd]+m3d[nd])
            end
            t[i] = 0.5*(m2+m3)
        else
            for nd=1:nbdirs
                td[nd,i] = ((w1d[nd]*m2+w1*m2d[nd]+w2d[nd]*m3+w2*m3d[nd])*(w1+
                w2)-(w1*m2+w2*m3)*(w1d[nd]+w2d[nd]))/(w1+w2)^2
            end
            t[i] = (w1*m2+w2*m3)/(w1+w2)
        end
    end
    for nd=1:nbdirs
        p0d[nd,:] = 0.0
        p1d[nd,:] = 0.0
        p2d[nd,:] = 0.0
        p3d[nd,:] = 0.0
    end
    # polynomial cofficients
    for i=1:n-1
        dx = xpt[i+1] - xpt[i]
        t1 = t[i]
        t2 = t[i+1]
        for nd=1:nbdirs
            dxd[nd] = xptd[nd, i+1] - xptd[nd,i]
            t1d[nd] = td[nd,i]
            t2d[nd] = td[nd, i+1]
            p0d[nd,i] = yptd[nd,i]
            p1d[nd,i] = t1d[nd]
            p2d[nd,i] = ((3.0*md[nd,2+i]-2.0*t1d[nd]-t2d[nd])*dx-(3.0*
            m[2+i]-2.0*t1-t2)*dxd[nd])/dx^2
            p3d[nd,i] = ((t1d[nd]+t2d[nd]-2.0*md[nd,2+i])*dx^2-(t1+t2-
            2.0*m[2+i])*2*dx*dxd[nd])/(dx^2)^2
        end
        p0[i] = ypt[i]
        p1[i] = t1
        p2[i] = (3.0*m[2+i]-2.0*t1-t2)/dx
        p3[i] = (t1+t2-2.0*m[2+i])/dx^2
    end
    return p0,p0d,p1,p1d,p2,p2d,p3,p3d

end # setup_dv

#  Differentiation of abs_smooth in forward (tangent) mode:
#   variations   of useful results: y
#   with respect to varying inputs: x

function abs_smooth_dv(x, xd, delta_x)
    #   USE DIFFSIZES
    #  Hint: nbdirsmax should be the maximum number of differentiation directions

    nbdirs = length(xd)

    # out

    yd = zeros(nbdirs)

    if (x >= delta_x)
        for nd=1:nbdirs
            yd[nd] = xd[nd]
        end
        y = x
    elseif (x <= -delta_x)
        for nd=1:nbdirs
            yd[nd] = -xd[nd]
        end
        y = -x
    else
        for nd=1:nbdirs
            yd[nd] = 2.0*x*xd[nd]/(2.0*delta_x)
        end
        y = x^2/(2.0*delta_x) + delta_x/2.0
    end
    return y, yd
end # abs_smooth_dv

end #module
