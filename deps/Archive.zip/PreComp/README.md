# PreComp
classical laminate theory for composite wings/blades based on: https://nwtc.nrel.gov/PreComp

Jacobians can be obtained through automatic differentiation using `PreComp.propertiesderiv`.

[![Build Status](https://travis-ci.org/taylormcd/PreComp.jl.svg?branch=master)](https://travis-ci.org/taylormcd/PreComp.jl)

[![Coverage Status](https://coveralls.io/repos/taylormcd/PreComp.jl/badge.svg?branch=master&service=github)](https://coveralls.io/github/taylormcd/PreComp.jl?branch=master)

[![codecov.io](http://codecov.io/github/taylormcd/PreComp.jl/coverage.svg?branch=master)](http://codecov.io/github/taylormcd/PreComp.jl?branch=master)
