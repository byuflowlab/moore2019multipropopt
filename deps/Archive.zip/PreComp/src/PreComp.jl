module PreComp
import ForwardDiff
import DiffResults

export properties,tw_rate

# translated version of PreComp from NREL
include("main.jl")

# method for getting derivatives
include("deriv.jl")

# methods to read PreComp input files
include("io.jl")

end # module
