"""
Struct for holding inputs to PreComp.properties()
"""
struct derivinput
  chord::Float64
  tw_aero_d::Float64
  tw_prime_d::Float64
  le_loc::Float64
  xnode::Array{Float64,1}
  ynode::Array{Float64,1}
  e1::Array{Float64,1}
  e2::Array{Float64,1}
  g12::Array{Float64,1}
  anu12::Array{Float64,1}
  density::Array{Float64,1}
  xsec_nodeU::Array{Float64,1}
  t_lamU::Array{Float64,1}
  tht_lamU::Array{Float64,1}
  xsec_nodeL::Array{Float64,1}
  t_lamL::Array{Float64,1}
  tht_lamL::Array{Float64,1}
  loc_web::Array{Float64,1}
  t_lamW::Array{Float64,1}
  tht_lamW::Array{Float64,1}
end

"""
Struct type for holding outputs of PreComp.properties()
"""
struct derivoutput
  ei_flap::derivinput
  ei_lag::derivinput
  gj::derivinput
  ea::derivinput
  s_fl::derivinput
  s_af::derivinput
  s_al::derivinput
  s_ft::derivinput
  s_lt::derivinput
  s_at::derivinput
  x_sc::derivinput
  y_sc::derivinput
  x_tc::derivinput
  y_tc::derivinput
  mass::derivinput
  flap_iner::derivinput
  lag_iner::derivinput
  tw_iner_d::derivinput
  x_cm::derivinput
  y_cm::derivinput
end

function propertiesderiv(pc_input::input)
    l_chord  = length(pc_input.chord )
    l_tw_aero_d = length(pc_input.tw_aero_d)
    l_tw_prime_d = length(pc_input.tw_prime_d)
    l_le_loc = length(pc_input.le_loc)
    l_xnode = length(pc_input.xnode)
    l_ynode = length(pc_input.ynode)
    l_e1 = length(pc_input.e1)
    l_e2 = length(pc_input.e2)
    l_g12 = length(pc_input.g12)
    l_anu12 = length(pc_input.anu12)
    l_density = length(pc_input.density)
    l_xsec_nodeU = length(pc_input.xsec_nodeU)
    l_t_lamU = length(pc_input.t_lamU)
    l_tht_lamU = length(pc_input.tht_lamU)
    l_xsec_nodeL = length(pc_input.xsec_nodeL)
    l_t_lamL = length(pc_input.t_lamL)
    l_tht_lamL = length(pc_input.tht_lamL)
    l_loc_web = length(pc_input.loc_web)
    l_t_lamW = length(pc_input.t_lamW)
    l_tht_lamW = length(pc_input.tht_lamW)
    lengths = [l_chord,l_tw_aero_d,l_tw_prime_d,l_le_loc,l_xnode,l_ynode,l_e1,
               l_e2,l_g12,l_anu12,l_density,l_xsec_nodeU,l_t_lamU,l_tht_lamU,
               l_xsec_nodeL,l_t_lamL,l_tht_lamL,l_loc_web,l_t_lamW,l_tht_lamW]
    cumsum_lengths = cumsum(lengths)
    function fun(x)
        chord = x[1]
        tw_aero_d = x[2]
        tw_prime_d = x[3]
        le_loc = x[4]
        xnode = x[1+cumsum_lengths[4]:(cumsum_lengths[5])]
        ynode = x[1+cumsum_lengths[5]:(cumsum_lengths[6])]
        e1 = x[1+cumsum_lengths[6]:(cumsum_lengths[7])]
        e2 = x[1+cumsum_lengths[7]:(cumsum_lengths[8])]
        g12 = x[1+cumsum_lengths[8]:(cumsum_lengths[9])]
        anu12 = x[1+cumsum_lengths[9]:(cumsum_lengths[10])]
        density = x[1+cumsum_lengths[10]:(cumsum_lengths[11])]
        xsec_nodeU = x[1+cumsum_lengths[11]:(cumsum_lengths[12])]
        t_lamU = x[1+cumsum_lengths[12]:(cumsum_lengths[13])]
        tht_lamU = x[1+cumsum_lengths[13]:(cumsum_lengths[14])]
        xsec_nodeL = x[1+cumsum_lengths[14]:(cumsum_lengths[15])]
        t_lamL = x[1+cumsum_lengths[15]:(cumsum_lengths[16])]
        tht_lamL = x[1+cumsum_lengths[16]:(cumsum_lengths[17])]
        if isempty(pc_input.loc_web)
          loc_web = Float64[]
          t_lamW = Float64[]
          tht_lamW = Float64[]
        else
          loc_web = x[1+cumsum_lengths[17]:(cumsum_lengths[18])]
          t_lamW = x[1+cumsum_lengths[18]:(cumsum_lengths[19])]
          tht_lamW = x[1+cumsum_lengths[19]:(cumsum_lengths[20])]
        end
        result = PreComp.properties(chord,tw_aero_d,tw_prime_d,le_loc,xnode,
          ynode,e1,e2,g12,anu12,density,xsec_nodeU,pc_input.n_laminaU,pc_input.n_pliesU,
          t_lamU,tht_lamU,pc_input.mat_lamU,xsec_nodeL,pc_input.n_laminaL,
          pc_input.n_pliesL, t_lamL, tht_lamL,pc_input.mat_lamL,loc_web,
          pc_input.n_laminaW, pc_input.n_pliesW,t_lamW,tht_lamW,pc_input.mat_lamW)
      return [i for i in result[1:20]]
    end
    x = vcat(pc_input.chord,pc_input.tw_aero_d,pc_input.tw_prime_d,
      pc_input.le_loc,pc_input.xnode,pc_input.ynode,
      pc_input.e1, pc_input.e2,pc_input.g12, pc_input.anu12,pc_input.density,
      pc_input.xsec_nodeU,pc_input.t_lamU, pc_input.tht_lamU,
      pc_input.xsec_nodeL,pc_input.t_lamL, pc_input.tht_lamL,
      pc_input.loc_web,pc_input.t_lamW, pc_input.tht_lamW)
   out = DiffResults.DiffResult(zeros(20),zeros(20,length(x)))
   ForwardDiff.jacobian!(out,fun,x)
   f = DiffResults.value(out)
   dfdx = DiffResults.jacobian(out)
   # assemble derivatives into structure
   outputderivs = Array{derivinput,1}(20)
   for i = 1:20
        inputderivs = Array{Union{Float64,Array{Float64,1}},1}(20)
        for j = 1:4
          inputderivs[j] = dfdx[i,cumsum_lengths[j]]
        end
        for j = 5:20
          inputderivs[j] = dfdx[i,1+cumsum_lengths[j-1]:(cumsum_lengths[j])]
        end
        outputderivs[i] = derivinput(inputderivs...)
    end
    return output(f...),derivoutput(outputderivs...)
end
