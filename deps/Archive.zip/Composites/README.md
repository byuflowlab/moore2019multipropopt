# Composites

[![Build Status](https://travis-ci.org/taylormcd/Composites.jl.svg?branch=master)](https://travis-ci.org/taylormcd/Composites.jl)

[![Coverage Status](https://coveralls.io/repos/taylormcd/Composites.jl/badge.svg?branch=master&service=github)](https://coveralls.io/github/taylormcd/Composites.jl?branch=master)

[![codecov.io](http://codecov.io/github/taylormcd/Composites.jl/coverage.svg?branch=master)](http://codecov.io/github/taylormcd/Composites.jl?branch=master)
