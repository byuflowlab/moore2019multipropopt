module Gradients

using ForwardDiff
using ReverseDiff
import Roots

"""
Forward finite difference.  Evaluates both function values and the Jacobian.
f and x can both be arrays
"""
function forwarddiff(fun, x; h=1e-6, parallel=false)

    Nin = length(x)
    step = Array{Float64,1}(Nin)
    xp = Array{Array{Float64,1},1}(Nin+1)

    # compute finite difference
    xp[1] = x
    for i = 1:Nin
        step[i] = h*abs(x[i])
        if h > 0
            step[i] = max(step[i], h)  # make sure step[i] size isn't too small (or 0)
        else
            step[i] = min(step[i], h)
        end
        xp[i+1] = copy(x)
        xp[i+1][i] += step[i]
    end

    # do all function calls at same time
    if parallel
        out = pmap(fun,xp)
    else
        out = map(fun,xp)
    end
    f = out[1]
    fp = out[2:end]

    # compute gradient
    Nout = length(f)
    dfdx = zeros(Nout,Nin)
    for i = 1:Nin
        dfdx[:,i] = (fp[i]-f)/step[i]
    end

    return f, dfdx
end

"""
Backward finite difference.
h should be positive.
"""
function backwarddiff(fun, x; h=1e-6, parallel=false)
    return forwarddiff(fun, x, h=-h)
end

"""
Central finite difference.
h should be positive.
"""
function centraldiff(fun, x; h=1e-4, parallel=false)

    Nin = length(x)
    step = Array{Float64,1}(Nin)
    xp = Array{Array{Float64,1},1}(2*Nin+1)

    # compute finite difference
    xp[1] = x
    for i = 1:Nin
        step[i] = h*abs(x[i])
        step[i] = max(step[i], h)  # make sure step size isn't too small (or 0)
        xp[2*i] = copy(x)
        xp[2*i][i] += step[i]
        xp[2*i+1] = copy(x)
        xp[2*i+1][i] -= step[i]
    end

    # do all function calls at same time
    if parallel
        out = pmap(fun,xp)
    else
        out = map(fun,xp)
    end
    f = out[1]
    fp = out[2:2:end]
    fm = out[3:2:end]

    # compute gradient
    Nout = length(f)
    dfdx = zeros(Nout,Nin)
    for i = 1:Nin
        dfdx[:, i] = (fp[i]-fm[i])/(2*step[i])
    end

    return f, dfdx
end


"""
Complex step
"""
function complexstep(fun, x; h=1e-30, parallel=false)

    Nin = length(x)
    step = Array{Float64,1}(Nin)
    xp = Array{Array{Complex128,1},1}(Nin+1)

    # compute finite difference
    xp[1] = x
    for i = 1:Nin
        xp[i+1] = copy(x)
        xp[i+1][i] += h*1im
    end

    f = fun(x)
    Nin = length(x)
    Nout = length(f)

    # do all function calls at same time
    if parallel
        out = pmap(fun,xp)
    else
        out = map(fun,xp)
    end

    f = real.(out[1])
    fc = out[2:end]

    # compute gradient
    Nout = length(f)
    dfdx = zeros(Nout,Nin)
    for i = 1:Nin
        dfdx[:,i] = imag(fc[i])/h
    end

    return f, dfdx
end


"""
check gradients in gcheck against centraldiff
"""
function check(func, x, gcheck, gtol=1e-6)

    f, gfd = centraldiff(func, x)

    nf = length(f)
    nx = length(x)
    gerror = zeros(nf, nx)

    for j = 1:nx
        for i = 1:nf
            if gcheck[i, j] <= gtol
                gerror[i, j] = abs(gcheck[i, j] - gfd[i, j])
            else
                gerror[i, j] = abs(1 - gfd[i, j]/gcheck[i, j])
            end
            if gerror[i, j] > gtol
                println("**** gerror(", i, ", ", j, ") = ", gerror[i, j])
            end
        end
    end

    return gerror
end


"""
Forward mode AD
"""
function forwardad(fun, x)

    f = fun(x)
    J = ForwardDiff.jacobian(fun, x)  # clearly a warapper is not needed here, however new AD methods are in development so it may be helpful to retain this wrapper.

    return f, J
end


function reverseadinit(fun, x)

    f_tape = ReverseDiff.JacobianTape(fun, x)
    const compiled_f_tape = ReverseDiff.compile(f_tape)  # TODO: need to save this outside of function scope if we will be reusing

    return compiled_f_tape
end

"""
Reverse mode AD
"""
function reversead(fun, x, ftape)

    f = fun(x)
    Nin = length(x)
    Nout = length(f)

    dfdx = zeros(Nout, Nin)
    ReverseDiff.jacobian!(dfdx, ftape, x)

    return f, dfdx
end

"""
An implementation of fzero that propgates derivative correctly with AD.
"""
function fzero(R, lower, upper)

    xstar = Roots.fzero(R, lower, upper)

    # a couple iterations of Newton's method to propagate the dual number.
    for i = 1:2
        dR = ForwardDiff.derivative(R, xstar)
        xstar = xstar - R(xstar)/dR
    end

    return xstar
end

end # module
