import Gradients
using Base.Test
import NLsolve

@testset "root-finding" begin

function getlambda(m)

    function residual(lambda)
        return lambda/m + cos(lambda)
    end
    lambda = Gradients.fzero(residual, -2.0, 2.0)
    
    return lambda
end

function fimplicit(mvec)

    m = mvec[1]

    lambda = getlambda(m)
    f = lambda*m^2
    return [f]
end

function getlambda_nd(m)

    function residual(F, lambda) 
        F[1] = lambda[1]/m[1] + cos(lambda[1])
    end
    results = NLsolve.nlsolve(residual, zeros(m), ftol=1e-15)
    
    lambda = results.zero
    
    return lambda
end

function fimplicit_nd(m)

    lambda = getlambda_nd(m)
    f = lambda.*m.^2
    return f
end


m = 1.2


# forward mode (bracketing)

_, dfdm1 = Gradients.forwardad(fimplicit, [m])

lambda = getlambda(m)
dfdm_exact = 2*lambda*m + lambda/(1.0/m - sin(lambda))

@test dfdm1[1] == dfdm_exact


# reverse mode (bracketing)

tape = Gradients.reverseadinit(fimplicit, [m])
_, dfdm2 = Gradients.reversead(fimplicit, [m], tape)

@test dfdm2[1] == dfdm_exact

# forward mode (ND root finding)
_, dfdm3 = Gradients.forwardad(fimplicit_nd, [m])

@test dfdm3[1] == dfdm_exact

# reverse mode (ND root finding)

# tape2 = Gradients.reverseadinit(fimplicit_nd, [m])
# _, dfdm4 = Gradients.reversead(fimplicit_nd, [m], tape2)

# @test dfdm4[1] == dfdm_exact


end # testset
# ---------------------------------------------

